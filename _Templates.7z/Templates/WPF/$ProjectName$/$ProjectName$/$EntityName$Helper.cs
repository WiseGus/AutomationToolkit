﻿using System;
using System.Linq;
using System.Text;
using SLnet.Base.Interfaces;
using $DomainName$.Core.Base;
using $DomainName$.Core.WpfForms;

namespace $ProjectName$ {

    public class $DomainPrefix$$EntityName$Helper : $DomainPrefix$WpfObjectHelper {
        
        public $DomainPrefix$$EntityName$Helper(IslAppContext appContext)
            : base(appContext) {
        }

        public override string GetEntityRegName() {
            return $DomainPrefix$Sys.GetRegName($DomainPrefix$ObjRegName$ModuleName$.$EntityName$);
        }

        public override bool GetDeleteIndividually() {
            return true;
        }
    }

}
