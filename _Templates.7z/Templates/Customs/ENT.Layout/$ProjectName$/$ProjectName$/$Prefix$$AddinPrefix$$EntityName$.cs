﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using $Prefix$$AddinName$.Entities;
using $Prefix$$AddinName$.Data.DataObjects;
using $Prefix$$AddinName$.Data.Structure;
using SLnet.Base.Interfaces;
using SLnet.Base.Attributes;
using SLnet.Base;
using SLnet.Base.DbUtils.Interfaces;
using SLnet.Base.DbUtils;
using SLnet.Base.DataObjects;
using $DomainName$.Core.Base.Trace;
using Reeb.SqlOM;
using Reeb.SqlOM.Render;
using $DomainName$.Core.Implementor;
using $Prefix$$AddinName$.Core.Base;


namespace $ProjectName$ {

    //Client Operations
    [slRegisterOperation("Post", typeof(Client_Post), slRegisterOperationTarget.Client)]
    [slRegisterOperation("Get", typeof(Client_Get), slRegisterOperationTarget.Client)]
    [slRegisterOperation("Delete", typeof(Client_Delete), slRegisterOperationTarget.Client)]

    //Server Operations
    [slRegisterOperation("Post", typeof(Server_Post), slRegisterOperationTarget.Server)]
    [slRegisterOperation("Get", typeof(Server_Get), slRegisterOperationTarget.Server)]
    [slRegisterOperation("Delete", typeof(Server_Delete), slRegisterOperationTarget.Server)]

    //Both 
    [slRegisterOperation("GetFetchPath", typeof(GetFetchPath), slRegisterOperationTarget.Both)]
    [slRegisterOperation("GetPostPath", typeof(GetPostPath), slRegisterOperationTarget.Both)]

    [slRegisterObject($Prefix$$AddinPrefix$ObjRegName.DomainName, $Prefix$$AddinPrefix$ObjRegName.$EntityName$)]
	public partial class $Prefix$$AddinPrefix$$EntityName$: $Prefix$$AddinPrefix$$EntityName$EntityBase {

        public $Prefix$$AddinPrefix$$EntityName$(IslAppContext appContext)
            : base(appContext) {

        }
	}

}
