﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SLnet.Base.Interfaces;
using $DomainName$.Core.Base;
using $DomainName$.Core.Base.Trace;
using $Prefix$$AddinName$.Data.DataObjects;
using $DomainName$.Core.Base.Structures;
using $Prefix$$AddinName$.Data.Structure;
using $DomainName$.Core.Implementor;
using SLnet.Base.DataObjects;

namespace $ProjectName$.Implementors {

    public class $Prefix$$AddinPrefix$$EntityName$ImplClient : $DomainPrefix$BaseImplClient {

        new protected $Prefix$$AddinPrefix$$EntityName$Impl Impl {
            get { return ($Prefix$$AddinPrefix$$EntityName$Impl)base.Impl; }
            set { base.Impl = value; }
        }

        public $Prefix$$AddinPrefix$$EntityName$ImplClient(IslAppContext appContext, $Prefix$$AddinPrefix$$EntityName$Impl impl)
            : base(appContext, impl) {
        }

        internal $DomainPrefix$MessageLogger Delete(string objectAlias, string methodAlias, slDataObjectProviderFetchPath fetchPath) {
            return ($DomainPrefix$MessageLogger)ExecOperation(objectAlias, methodAlias, fetchPath);
        }

    }
}
