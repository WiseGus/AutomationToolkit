namespace $ProjectName$ {
    partial class $Prefix$$AddinPrefix$$EntityName$F {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof($Prefix$$AddinPrefix$$EntityName$F));
            this.oc$EntityName$ = new $DomainName$.Core.WinControls.Data.$DomainPrefix$ObjectCollectionSource(this.components);
            this.bs$EntityName$ = new $DomainName$.Core.WinControls.Data.$DomainPrefix$BindingSource(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.MainGridLayoutItem)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.MainGridControl)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.MainGridControlView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.MainLayoutGroup)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.MainLayout)).BeginInit();
            this.MainLayout.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.MainPanel)).BeginInit();
            this.MainPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bs$EntityName$)).BeginInit();
            this.SuspendLayout();
            // 
            // MainGridControl
            // 
            this.MainGridControl.DataSource = this.bs$EntityName$;
            this.MainGridControl.EmbeddedNavigator.Buttons.Append.Visible = false;
            this.MainGridControl.EmbeddedNavigator.Buttons.CancelEdit.Visible = false;
            this.MainGridControl.EmbeddedNavigator.Buttons.Edit.Visible = false;
            this.MainGridControl.EmbeddedNavigator.Buttons.EnabledAutoRepeat = false;
            this.MainGridControl.EmbeddedNavigator.Buttons.EndEdit.Visible = false;
            this.MainGridControl.EmbeddedNavigator.Buttons.Remove.Visible = false;
            this.MainGridControl.EmbeddedNavigator.Name = "";
            // 
            // MainGridControlView
            // 
            this.MainGridControlView.OptionsBehavior.AutoPopulateColumns = false;
            this.MainGridControlView.OptionsView.NewItemRowPosition = DevExpress.XtraGrid.Views.Grid.NewItemRowPosition.Bottom;
            this.MainGridControlView.OptionsView.ShowGroupPanel = false;
            this.MainLayout.Controls.SetChildIndex(this.MainGridControl, 0);
            // 
            // oc$EntityName$
            // 
            this.oc$EntityName$.CollectionType = typeof($Prefix$$AddinName$.Data.DataObjects.$Prefix$$AddinPrefix$$EntityName$Collection);
            // 
            // bs$EntityName$
            // 
            this.bs$EntityName$.DataSource = this.oc$EntityName$;            
            // $Prefix$$AddinPrefix$$EntityName$F
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Name = "$Prefix$$AddinPrefix$$EntityName$F";
            ((System.ComponentModel.ISupportInitialize)(this.MainGridLayoutItem)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.MainGridControl)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.MainGridControlView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.MainLayoutGroup)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.MainLayout)).EndInit();
            this.MainLayout.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.MainPanel)).EndInit();
            this.MainPanel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.bs$EntityName$)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private $DomainName$.Core.WinControls.Data.$DomainPrefix$ObjectCollectionSource oc$EntityName$;
        private $DomainName$.Core.WinControls.Data.$DomainPrefix$BindingSource bs$EntityName$;        
    }
}