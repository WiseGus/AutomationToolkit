﻿using System;
using SLnet.Base.Customization.Interfaces;
using SLnet.Base.Customization;
using SLnet.Base.Interfaces;
using $DomainName$.Data.DataObjects;
using $DomainName$.Core.Base.Trace;


namespace $ProjectName$
{
    [slRegisterCustomDomainAppExtension()]
    public class $Prefix$$AddinPrefix$DomainAppExtension : IslCustomDomainAppExtension, IslCustomDomainAppObjectExtension
	{
      

        public void AfterExecuteOperation(ref object res, SLnet.Base.Interfaces.IslAppContext appContext, SLnet.Base.Interfaces.IslOperations container, SLnet.Base.slBaseOperation operation, params object[] args)
        {
        }


        public void BeforeExecuteOperation(SLnet.Base.Interfaces.IslAppContext appContext, SLnet.Base.Interfaces.IslOperations container, SLnet.Base.slBaseOperation operation, params object[] args)
        {
        }

       
    }
}
