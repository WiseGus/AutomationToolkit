using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using SLnet.Base.Attributes;
using SLnet.Sand.Base.Attributes;
using SLnet.Sand.WinForms.Forms;
using $DomainName$.Core.Base;
using $DomainName$.Core.Base.Trace;
using $DomainName$.Core.Messages;
using $DomainName$.Core.WinForms;
using $DomainName$.Data.DataObjects;
using $DomainName$.PRS.$ModuleName$.$EntityName$;
using $DomainName$.PRS.$ModuleName$.$EntityName$.Views;

namespace $ProjectName$ {

    [slsRegisterForm($DomainPrefix$ObjRegName.$DomainNameFull$, "$EntityName$")]
    public partial class $DomainPrefix$$EntityName$F : $DomainPrefix$MasterF, I$DomainPrefix$$EntityName$View {

        private $DomainPrefix$$EntityName$P _Presenter;

        [slActivatorDependency(slDependencyTarget.CreateAndAssign)]
        new public $DomainPrefix$$EntityName$P Presenter {
            get { return _Presenter; }
            set {
                _Presenter = value;
                base.Presenter = value;
            }
        }       

        [slActivatorDependency(slDependencyTarget.Assign)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        [Browsable(false)]
        public string AutoLoadID {
            get { return _AutoLoadID; }
            set { _AutoLoadID = value; }
        }

        [slActivatorDependency(slDependencyTarget.Assign)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        [Browsable(false)]
        public slsBrowserStuctResult AutoLoadBrowserStruct {
            get { return _AutoLoadStruct; }
            set {
                AutoLoadID = value.ID;
                SetAutoLoadStruct(value);
            }
        }

        public $DomainPrefix$$EntityName$F() {
            InitializeComponent();
            BindingSources.Add(bs$EntityName$);          
            //TODO:
            BrowserAction = "$DomainNameFull$:UI.$ModuleName$:$EntityName$Browser";
            this.Text = $DomainPrefix$ObjectNames.sObj$EntityName$;
            this.Description = $DomainPrefix$ObjectNames.sObj$EntityName$;  
        }                     

        #region I$DomainPrefix$$EntityName$View Members

        public new $DomainPrefix$$EntityName$DataObject CurrentItem {
            get {
                return base.CurrentItem as $DomainPrefix$$EntityName$DataObject;
            }
            set {
                base.CurrentItem = value;
            }
        }

        public new $DomainPrefix$$EntityName$Collection Items {
            get {
                return base.Items as $DomainPrefix$$EntityName$Collection;
            }
            set {
                base.Items = value;
            }
        }

        #endregion
      
    }

}