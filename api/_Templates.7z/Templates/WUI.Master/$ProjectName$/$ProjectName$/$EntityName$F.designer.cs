﻿namespace $ProjectName$ {
    partial class $DomainPrefix$$EntityName$F {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof($DomainPrefix$$EntityName$F));
            this.oc$EntityName$ = new $DomainName$.Core.WinControls.Data.$DomainPrefix$ObjectCollectionSource(this.components);
            this.bs$EntityName$ = new $DomainName$.Core.WinControls.Data.$DomainPrefix$BindingSource(this.components);
            this.ep$EntityName$ = new $DomainName$.Core.WinControls.DevExp.$DomainPrefix$ErrorProvider(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.MainLayoutGroup)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.MainLayout)).BeginInit();
            this.MainLayout.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.MainPanel)).BeginInit();
            this.MainPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bs$EntityName$)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ep$EntityName$)).BeginInit();
            this.SuspendLayout();
            // 
            // MainLayoutGroup
            // 
            this.MainLayoutGroup.Size = new System.Drawing.Size(423, 167);
            // 
            // MainLayout
            //             
            resources.ApplyResources(this.MainLayout, "MainLayout");
            // 
            // MainPanel
            // 
            resources.ApplyResources(this.MainPanel, "MainPanel");
            // 
            // oc$EntityName$
            // 
            this.oc$EntityName$.CollectionType = typeof($DomainName$.Data.DataObjects.$DomainPrefix$$EntityName$Collection);
            // 
            // bs$EntityName$
            // 
            this.bs$EntityName$.DataSource = this.oc$EntityName$;                        
            // 
            // ep$EntityName$
            // 
            this.ep$EntityName$.ContainerControl = this;
            this.ep$EntityName$.DataSource = this.bs$EntityName$;
            // 
            // $DomainPrefix$$EntityName$F
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Name = "$DomainPrefix$$EntityName$F";
            ((System.ComponentModel.ISupportInitialize)(this.MainLayoutGroup)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.MainLayout)).EndInit();
            this.MainLayout.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.MainPanel)).EndInit();
            this.MainPanel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.bs$EntityName$)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ep$EntityName$)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private $DomainName$.Core.WinControls.Data.$DomainPrefix$ObjectCollectionSource oc$EntityName$;
        private $DomainName$.Core.WinControls.Data.$DomainPrefix$BindingSource bs$EntityName$;
         private $DomainName$.Core.WinControls.DevExp.$DomainPrefix$ErrorProvider ep$EntityName$;
    }
}