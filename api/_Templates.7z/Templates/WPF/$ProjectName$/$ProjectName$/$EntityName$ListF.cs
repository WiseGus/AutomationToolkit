﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SLnet.Base.Interfaces;
using SLnet.Sand.Base.Attributes;
using $DomainName$.Core.Base;
using $DomainName$.Core.Messages;
using $DomainName$.Core.WpfForms;

namespace $ProjectName$ {
    
    [slsRegisterForm(gxObjRegName.$DomainNameFull$, "$EntityName$List")]
    public partial class $DomainPrefix$$EntityName$List : $DomainPrefix$BrowseF {
        
        new protected $DomainPrefix$$EntityName$Helper ListHelper {
            get { return base.ListHelper as $DomainPrefix$$EntityName$Helper; }
            set { base.ListHelper = value; }
        }

        public $DomainPrefix$$EntityName$List() {
            InitializeComponent();            
        }

        public override void Init(IslAppContext appContext) {
            base.Init(appContext);
            ListHelper = new $DomainPrefix$$EntityName$Helper(appContext);
            //TODO: define signature fields
            SignatureFields = new List<string>() { "XXX" };
        }

        protected override bool BrowserStructSupport() {
            return true;
        }           

        public override string GetBrowserDefinition() {
            //TODO: Check the browser name    
           return "$DomainPrefix$$EntityName$";
        }

        public override string GetFormName() {
             //TODO: Check the form name 
            return "$DomainNameFull$:UI.$ModuleName$:$EntityName$";
        }

        public override string GetListDescription() {
            //TODO: Check the resource string              
            return $DomainPrefix$Resources.sListName;
        }

        public override string GetObjectDescription() {            
            return $DomainPrefix$ObjectNames.sObj$EntityName$;                        
        }       
       
    }
}
