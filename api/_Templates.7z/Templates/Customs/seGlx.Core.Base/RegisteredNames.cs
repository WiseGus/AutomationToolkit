﻿using System;

namespace $Prefix$$AddinName$.Core.Base
{

    public class $Prefix$$AddinPrefix$ObjRegName {
        public const string DomainName = "$DomainName$";
        public const string AliasName = "UI.$AliasName$";

        #region ENTITIES
        #endregion

        #region LISTS
        #endregion
        
    }
   
}
