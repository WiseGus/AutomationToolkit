﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using $Prefix$$AddinName$.Data.DataObjects;
using $DomainName$.Core.Presenters.Views;

namespace $safeprojectname$ {

    public interface I$Prefix$$AddinPrefix$$EntityName$View : I$DomainPrefix$ArrayView<$Prefix$$AddinPrefix$$EntityName$Collection, $Prefix$$AddinPrefix$$EntityName$DataObject> {
    }

}
