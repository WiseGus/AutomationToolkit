﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using Glx.Core.WinForms;
using $Prefix$$AddinName$.Data.DataObjects;
using SLnet.Sand.WinControls;
using SLnet.Base.Interfaces;
using Glx.Core.Base.Trace;
using SLnet.Sand.Base.Attributes;
using $Prefix$$AddinName$.Core.Base;

namespace $safeprojectname$ {

    [slsRegisterForm($Prefix$$AddinPrefix$ObjRegName.DomainName, $Prefix$$AddinPrefix$ObjRegName.$EntityName$)]
    public partial class $Prefix$$AddinPrefix$$EntityName$F: gxLayoutF
	{
        private $Prefix$$AddinPrefix$$EntityName$Collection _Collection;

        public $Prefix$$AddinPrefix$$EntityName$F()
		{
            InitializeComponent();
		}

        public override void Init(IslAppContext appContext)
        {
            base.Init(appContext);
            _Collection = $Prefix$$AddinPrefix$$EntityName$CollectionFactory.Create(appContext);
            _Collection.DisableAllRules();
            bs$EntityName$.DataSource = _Collection.DefaultView;

            LoadData();
            this.UICommands.Add(new slsUICommandBinding(
                new slsUICommand($Prefix$$AddinPrefix$Resources.sSaveAndClose, "SaveAndClose", slsUICommandType.Button)));
            this.UICommands.Add(new slsUICommandBinding(
                new slsUICommand($Prefix$$AddinPrefix$Resources.sReload, "Reload", slsUICommandType.BarButton)));
            this.UICommands.Add(new slsUICommandBinding(
                new slsUICommand($Prefix$$AddinPrefix$Resources.sSave, "Save", slsUICommandType.BarButton)));
            this.UICommands["SaveAndClose"].OnCommandExecute += new slsUICommandBindingCommandExecuteEvent($Prefix$$AddinPrefix$$EntityName$F_OnCommandExecute);
            this.UICommands["Save"].OnCommandExecute += new slsUICommandBindingCommandExecuteEvent($Prefix$$AddinPrefix$$EntityName$F_OnCommandExecute);
            this.UICommands["Reload"].OnCommandExecute += new slsUICommandBindingCommandExecuteEvent($Prefix$$AddinPrefix$$EntityName$F_OnCommandExecute);

        }

        void $Prefix$$AddinPrefix$$EntityName$F_OnCommandExecute(slsUICommandEventArgs args)
        {
            switch (args.Sender.Name)
            {
                case "SaveAndClose":
                    if (SaveData()) Close();
                    break;
                case "Save":
                    SaveData();
                    LoadData();
                    break;
                case "Reload":
                    LoadData();
                    break;
            }
        }

        private bool SaveData()
        {
            var sc = AppContext.ServiceLocator.GetService<IslObjectActivator>();
            using (var obj = sc.CreateObject($Prefix$$AddinPrefix$Sys.GetRegName($Prefix$$AddinPrefix$ObjRegName.$EntityName$)))
            {
                bs$EntityName$.EndEdit();
                if (_Collection.IsDirty)
                    try
                    {
                      obj.ExecuteOperation("Post", _Collection);
                        return true;
                    }
                    catch (Exception ex)
                    {
                        HandleException(ex, "Error");
                    }
            }
            return false;
        }

        private void LoadData()
        {
            var sc = AppContext.ServiceLocator.GetService<IslObjectActivator>();
            using (var obj = sc.CreateObject($Prefix$$AddinPrefix$Sys.GetRegName($Prefix$$AddinPrefix$ObjRegName.$EntityName$)))
            {
                var fp = obj.ExecuteOperation("GetFetchPath");
                var x = obj.ExecuteOperation("Get", fp) as $Prefix$$AddinPrefix$$EntityName$Collection;
                _Collection.Fill(x);
                if (_Collection.Count == 0) _Collection.Add(_Collection.New());
                _Collection.ResetDirtyFlag();
            }
        }

        public override void CleanUp()
        {
            base.CleanUp();
        }
	}
}