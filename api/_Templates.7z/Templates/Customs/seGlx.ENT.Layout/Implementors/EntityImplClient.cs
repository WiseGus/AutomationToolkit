﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SLnet.Base.Interfaces;
using Glx.Core.Base;
using Glx.Core.Base.Trace;
using $Prefix$$AddinName$.Data.DataObjects;
using Glx.Core.Base.Structures;
using $Prefix$$AddinName$.Data.Structure;
using Glx.Core.Implementor;
using SLnet.Base.DataObjects;

namespace $safeprojectname$.Implementors {

    public class $Prefix$$AddinPrefix$$EntityName$ImplClient : gxBaseImplClient {

        new protected $Prefix$$AddinPrefix$$EntityName$Impl Impl {
            get { return ($Prefix$$AddinPrefix$$EntityName$Impl)base.Impl; }
            set { base.Impl = value; }
        }

        public $Prefix$$AddinPrefix$$EntityName$ImplClient(IslAppContext appContext, $Prefix$$AddinPrefix$$EntityName$Impl impl)
            : base(appContext, impl) {
        }

        internal gxMessageLogger Delete(string objectAlias, string methodAlias, slDataObjectProviderFetchPath fetchPath) {
            return (gxMessageLogger)ExecOperation(objectAlias, methodAlias, fetchPath);
        }

    }
}
