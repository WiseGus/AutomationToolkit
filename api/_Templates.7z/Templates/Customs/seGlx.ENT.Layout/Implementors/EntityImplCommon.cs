﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SLnet.Base.DataObjects;
using SLnet.Base.Interfaces;
using Glx.Core.Implementor;

namespace $safeprojectname$.Implementors {
   
    public class $Prefix$$AddinPrefix$$EntityName$ImplCommon : gxBaseImplCommon {
        
        new protected $Prefix$$AddinPrefix$$EntityName$Impl Impl {
            get { return ($Prefix$$AddinPrefix$$EntityName$Impl)base.Impl; }
            set { base.Impl = value; }
        }

        public $Prefix$$AddinPrefix$$EntityName$ImplCommon(IslAppContext appContext, $Prefix$$AddinPrefix$$EntityName$Impl impl)
            : base(appContext, impl) {
        }

        //TODO: override GetFetchPath, GetPostPath if needed
    }
}
