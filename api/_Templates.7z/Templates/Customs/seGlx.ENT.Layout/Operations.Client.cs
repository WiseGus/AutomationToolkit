﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SLnet.Base;
using SLnet.Base.Attributes;
using SLnet.Base.DataObjects;
using SLnet.Base.Interfaces;
using Glx.Core.Base;
using Glx.Core.Base.Trace;
using $Prefix$$AddinName$.ENT.$EntityName$.Implementors;
using Glx.Core.Base.Structures;
using $Prefix$$AddinName$.Data.DataObjects;


namespace $safeprojectname$ {

    partial class $Prefix$$AddinPrefix$$EntityName$ {
        
        [slWorkflowNonVisible()]
        public class Client_Get : slBaseObjectOperation {
            [slOperationMethod]
            public $Prefix$$AddinPrefix$$EntityName$Collection Execute(slDataObjectProviderFetchPath fetchPath) {
                $Prefix$$AddinPrefix$$EntityName$Impl impl = new $Prefix$$AddinPrefix$$EntityName$Impl(AppContext);
                return ($Prefix$$AddinPrefix$$EntityName$Collection)impl.Client.Get(impl.entityRegName, "Get", fetchPath);
            }
        }

        [slWorkflowNonVisible()]
        public class Client_Post : slBaseObjectOperation {
            [slOperationMethod]
            public gxMessageLogger Execute($Prefix$$AddinPrefix$$EntityName$Collection collection) {
                $Prefix$$AddinPrefix$$EntityName$Impl impl = new $Prefix$$AddinPrefix$$EntityName$Impl(AppContext);
                return impl.Client.Post(impl.entityRegName, "Post", collection);
            }
        }

        [slWorkflowNonVisible()]
        public class Client_Delete : slBaseObjectOperation {
            [slOperationMethod]
            public gxMessageLogger Execute(slDataObjectProviderFetchPath fetchPath) {
                $Prefix$$AddinPrefix$$EntityName$Impl impl = new $Prefix$$AddinPrefix$$EntityName$Impl(AppContext);
                return impl.Client.Delete(impl.entityRegName, "Delete", fetchPath);
            }
        }
    }

}
