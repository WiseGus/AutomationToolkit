﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SLnet.Base;
using SLnet.Base.Attributes;
using SLnet.Base.DataObjects;
using SLnet.Base.Trace;
using $DomainName$.Core.Base;
using $DomainName$.Core.Base.SandExtensions;
using $DomainName$.Core.Base.Trace;
using $DomainName$.Core.Implementor;
using $Prefix$$AddinName$.Data.DataObjects;
using $Prefix$$AddinName$.Data.Structure;
using $Prefix$$AddinName$.ENT.$EntityName$.Implementors;
using $DomainName$.Core.Base.Structures;

namespace $ProjectName$ {

    partial class $Prefix$$AddinPrefix$$EntityName$ 
    {

        [slWorkflowNonVisible()]
        public class Server_Get : slBaseObjectOperation {
            [slOperationMethod]
            public $Prefix$$AddinPrefix$$EntityName$DataContext Execute(slDataObjectProviderFetchPath fetchPath) {
                $Prefix$$AddinPrefix$$EntityName$Impl impl = new $Prefix$$AddinPrefix$$EntityName$Impl(AppContext);
                return impl.Server.Get(fetchPath);
            }
        }

        [slWorkflowNonVisible()]
        public class Server_Post : slTransactionalOperation
        {
            [slOperationMethod]
            public $DomainPrefix$MessageLogger Execute($Prefix$$AddinPrefix$$EntityName$DataContext dataContext){
                $Prefix$$AddinPrefix$$EntityName$Impl impl = new $Prefix$$AddinPrefix$$EntityName$Impl(AppContext);
                return impl.Server.Post(dataContext);
            }
        }

        [slWorkflowNonVisible()]
        public class Server_Delete : slTransactionalOperation
        {
            [slOperationMethod]
            public $DomainPrefix$MessageLogger Execute(slDataObjectProviderFetchPath fetchPath){
                $Prefix$$AddinPrefix$$EntityName$Impl impl = new $Prefix$$AddinPrefix$$EntityName$Impl(AppContext);
                return impl.Server.Delete(fetchPath);
            }
        }

    }
}
