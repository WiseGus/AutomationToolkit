﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SLnet.Base.Trace;
using SLnet.Base.Interfaces;
using $DomainName$.Core.Base;
using $DomainName$.Core.Base.Trace;
using $DomainName$.Core.Base.Structures;
using SLnet.Base.DataObjects;
using $DomainName$.Core.Base.SandExtensions;
using SLnet.Base.DbUtils.Interfaces;
using Reeb.SqlOM;
using Reeb.SqlOM.Render;
using SLnet.Base.DbUtils;
using $DomainName$.Core.Implementor;
using System.Data;
using SLnet.Sand.Base.Interfaces;
using $Prefix$$AddinName$.Data.Structure;
using $Prefix$$AddinName$.Data.DataObjects;
using SLnet.Base;

namespace $ProjectName$.Implementors {

    public class $Prefix$$AddinPrefix$$EntityName$ImplServer : $DomainPrefix$BaseImplServer {

        new protected $Prefix$$AddinPrefix$$EntityName$Impl Impl {
            get { return ($Prefix$$AddinPrefix$$EntityName$Impl)base.Impl; }
            set { base.Impl = value; }
        }

        public $Prefix$$AddinPrefix$$EntityName$ImplServer(IslAppContext appContext, $Prefix$$AddinPrefix$$EntityName$Impl impl)
            : base(appContext, impl) {
        }

        internal $Prefix$$AddinPrefix$$EntityName$DataContext Get(slDataObjectProviderFetchPath fetchPath) {
            $Prefix$$AddinPrefix$$EntityName$Collection collection = $Prefix$$AddinPrefix$$EntityName$CollectionFactory.Create(AppContext);
            slDataObjectProvider provider = new slDataObjectProvider(AppContext);
            provider.Fill(collection, fetchPath);
            return collection.DataContext;
        }

        internal $DomainPrefix$MessageLogger Post($Prefix$$AddinPrefix$$EntityName$DataContext dataContext) {
            $DomainPrefix$MessageLogger logger = new $DomainPrefix$MessageLogger();
            $Prefix$$AddinPrefix$$EntityName$Collection collection = $Prefix$$AddinPrefix$$EntityName$CollectionFactory.Create(AppContext, dataContext);
            if (collection.Count > 0) {
                try {
                    slDataObjectProvider provider = new slDataObjectProvider(AppContext);
                    slDataObjectProviderPostPath postPath = Impl.Common.GetPostPath();
                    provider.Save(collection, postPath);
                }
                catch (Exception e) {
                    logger.Merge($DomainPrefix$Sys.HandleException(e));
                }
            }
            return logger;
        }

        internal $DomainPrefix$MessageLogger Delete(slDataObjectProviderFetchPath fetchPath) {
            $DomainPrefix$MessageLogger logger = new $DomainPrefix$MessageLogger();
            $Prefix$$AddinPrefix$$EntityName$Collection collection = $Prefix$$AddinPrefix$$EntityName$CollectionFactory.Create(AppContext);
            slDataObjectProvider provider = new slDataObjectProvider(AppContext);
            provider.Fill(collection, fetchPath);
            for (int i = collection.Count - 1; i >= 0; i--) {
                collection[i].Delete();
            }
            provider.Save(collection);
            return logger;
        }

    }
}
