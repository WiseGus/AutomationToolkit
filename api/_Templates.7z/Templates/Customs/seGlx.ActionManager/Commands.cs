﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Glx.Core.ActionManager;
using SLnet.Base.Interfaces;
using SLnet.Base.Attributes;
using $Prefix$$AddinName$.Core.Base;

namespace $Prefix$$AddinName$.Core.ActionManager
{
    
    #region FORM ACTIONS REGISTRATION
    #endregion

    #region LIST ACTIONS REGISTRATION
    #endregion

    #region BROWSER ACTIONS REGISTRATION
    #endregion

    #region REPORT ACTIONS REGISTRATION
    #endregion


    [slRegisterObject($Prefix$$AddinPrefix$ObjRegName.DomainName, $Prefix$$AddinPrefix$ObjRegName.AliasName)]
    public class $Prefix$$AddinPrefix$Commands: gxBaseActionsManager{

        public $Prefix$$AddinPrefix$Commands(IslAppContext appContext)
            : base(appContext) {
        }

        #region FORM ACTIONS DECLARATION
        #endregion

        #region LIST ACTIONS DECLARATION
        #endregion

        #region BROWSER ACTIONS DECLARATION
        #endregion

        #region REPORTS ACTIONS DECLARATION
        #endregion

	}

}
