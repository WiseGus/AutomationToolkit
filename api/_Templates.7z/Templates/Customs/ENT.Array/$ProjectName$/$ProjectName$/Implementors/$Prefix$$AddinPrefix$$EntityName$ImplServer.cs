﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SLnet.Base.Trace;
using SLnet.Base.Interfaces;
using $DomainName$.Core.Base;
using $DomainName$.Core.Base.Trace;
using $DomainName$.Core.Messages;
using $Prefix$$AddinName$.Data.Structure;
using $DomainName$.Core.Implementor;

namespace $ProjectName$.Implementors {
 
    public class $Prefix$$AddinPrefix$$EntityName$ImplServer : $DomainPrefix$ArrayImplServer {

        new protected $Prefix$$AddinPrefix$$EntityName$Impl Impl {
            get { return ($Prefix$$AddinPrefix$$EntityName$Impl)base.Impl; }
            set { base.Impl = value; }
        }

        public $Prefix$$AddinPrefix$$EntityName$ImplServer(IslAppContext appContext, $Prefix$$AddinPrefix$$EntityName$Impl impl)
            : base(appContext, impl) {
        }        
        
        //TODO: override ValidateForPostSpecific, SaveWarningsSpecific if needed
    }

}
