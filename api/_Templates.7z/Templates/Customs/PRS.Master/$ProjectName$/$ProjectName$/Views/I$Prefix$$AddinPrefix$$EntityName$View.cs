﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using $DomainName$.Core.Presenters.Views;
using $DomainName$.Data.DataObjects;
using $Prefix$$AddinName$.Data.DataObjects;

namespace $ProjectName$.Views {

    public interface I$Prefix$$AddinPrefix$$EntityName$View : I$DomainPrefix$MasterView< $Prefix$$AddinPrefix$$EntityName$Collection, $Prefix$$AddinPrefix$$EntityName$DataObject> {
    }

}
