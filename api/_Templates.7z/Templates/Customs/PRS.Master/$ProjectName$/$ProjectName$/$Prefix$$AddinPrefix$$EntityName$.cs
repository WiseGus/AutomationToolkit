﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SLnet.Base.Attributes;
using SLnet.Base.Interfaces;
using $Prefix$$AddinName$.Entities;
using $DomainName$.Core.Base.SandExtensions;
using $DomainName$.Core.Messages;
using $DomainName$.Core.Presenters;
using $Prefix$$AddinName$.ENT.$EntityName$.Implementors;
using $Prefix$$AddinName$.Core.Base;

using $ProjectName$.Views;

namespace $ProjectName$ {

    public class $Prefix$$AddinPrefix$$EntityName$P : $DomainPrefix$MasterPresenter<I$Prefix$$AddinPrefix$$EntityName$View, $Prefix$$AddinPrefix$$EntityName$EntityBase> {

        public $Prefix$$AddinPrefix$$EntityName$P(IslAppContext appContext, I$Prefix$$AddinPrefix$$EntityName$View view, $Prefix$$AddinPrefix$$EntityName$EntityBase entity)
            : base(appContext, view, entity, $Prefix$$AddinPrefix$$EntityName$Impl.GetEntityRegName(), $Prefix$$AddinPrefix$ObjRegName.$EntityName$) {
        }

        [slDependencyConstructor]
        public $Prefix$$AddinPrefix$$EntityName$P(IslAppContext appContext, I$Prefix$$AddinPrefix$$EntityName$View view) 
            : this(appContext, view, null) {
        }
       
    }

}
