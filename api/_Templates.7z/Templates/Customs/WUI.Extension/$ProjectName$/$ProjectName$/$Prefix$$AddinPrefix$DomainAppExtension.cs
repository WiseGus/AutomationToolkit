﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;
using SLnet.Base.Customization.Interfaces;
using SLnet.Sand.Base.Customization.Interfaces;
using SLnet.Base.Interfaces;
using SLnet.Sand.WinForms.Forms;
using SLnet.Base.Customization;
using SLnet.Sand.Base.Interfaces;
using $DomainName$.WUI.$ModuleName$.$EntityName$;
using DevExpress.XtraLayout;
using $DomainName$.Core.WinControls.AdvControls;
using SLnet.Base.DataObjects;
using SLnet.Sand.Base.Forms;
using $DomainName$.Data.DataObjects;

namespace $ProjectName$ {

    [slRegisterCustomDomainAppExtension()]
	public class $Prefix$$AddinPrefix$DomainAppExtension: IslCustomDomainAppExtension, IslsCustomDomainAppFormExtension	{
        
        public $Prefix$$AddinPrefix$DomainAppExtension() {
        }


        public void Create(IslAppContext appContext, IslsForm form) {
            
        }

        public void ExecuteLink(IslAppContext appContext, IslsForm form, string command) {
            
        }

        public Dictionary<string, string> GetLinks(IslAppContext appContext, IslsForm form) {

            Dictionary<string, string> dc = null;
            return dc;
        }

        public void Init(IslAppContext appContext, IslsForm form) {
            
        }
    
        public void SyncScreen(IslAppContext appContext, IslsForm form) {

        }



    }

}
