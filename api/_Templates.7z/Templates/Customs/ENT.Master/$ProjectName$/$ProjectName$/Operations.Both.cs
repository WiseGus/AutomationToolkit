﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SLnet.Base;
using SLnet.Base.Attributes;
using SLnet.Base.DataObjects;
using $ProjectName$.Implementors;

namespace $ProjectName$ {

    partial class $Prefix$$AddinPrefix$$EntityName$ {
        
        [slWorkflowNonVisible()]
        public class GetFetchPath : slBaseObjectOperation {
            [slOperationMethod]
            public slDataObjectProviderFetchPath Execute() {                
                $Prefix$$AddinPrefix$$EntityName$Impl impl = new $Prefix$$AddinPrefix$$EntityName$Impl(AppContext);
                return impl.Common.GetFetchPath();
            }
        }

        [slWorkflowNonVisible()]
        public class GetPostPath : slBaseObjectOperation {
            [slOperationMethod]
            public slDataObjectProviderPostPath Execute() {                
                $Prefix$$AddinPrefix$$EntityName$Impl impl = new $Prefix$$AddinPrefix$$EntityName$Impl(AppContext);
                return impl.Common.GetPostPath();
            }
        }
            
    }
}
