﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SLnet.Base.Interfaces;
using $DomainName$.Core.Base;
using $DomainName$.Core.Base.Trace;
using $Prefix$$AddinName$.Data.DataObjects;
using $DomainName$.Core.Implementor;

namespace $ProjectName$.Implementors {

    public class $Prefix$$AddinPrefix$$EntityName$ImplClient : $DomainPrefix$MasterImplClient {

        new protected $Prefix$$AddinPrefix$$EntityName$Impl Impl {
            get { return ($Prefix$$AddinPrefix$$EntityName$Impl)base.Impl; }
            set { base.Impl = value; }
        }

        public $Prefix$$AddinPrefix$$EntityName$ImplClient(IslAppContext appContext, $Prefix$$AddinPrefix$$EntityName$Impl impl)
            : base(appContext, impl) {
        }
              
    }
}
