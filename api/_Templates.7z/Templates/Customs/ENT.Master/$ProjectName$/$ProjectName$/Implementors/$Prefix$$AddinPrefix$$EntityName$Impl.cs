﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SLnet.Base.Interfaces;
using $DomainName$.Core.Base;
using $DomainName$.Core.Messages;
using $DomainName$.Core.Implementor;
using $Prefix$$AddinName$.Core.Base;

namespace $ProjectName$.Implementors {

    public class $Prefix$$AddinPrefix$$EntityName$Impl : $DomainPrefix$MasterImpl {

       new public $Prefix$$AddinPrefix$$EntityName$ImplClient Client {
            get { return ($Prefix$$AddinPrefix$$EntityName$ImplClient)base.Client; }
            set { base.Client = value; }
        }
        new public $Prefix$$AddinPrefix$$EntityName$ImplServer Server {
            get { return ($Prefix$$AddinPrefix$$EntityName$ImplServer)base.Server; }
            set { base.Server = value; }
        }
        new public $Prefix$$AddinPrefix$$EntityName$ImplCommon Common {
            get { return ($Prefix$$AddinPrefix$$EntityName$ImplCommon)base.Common; }
            set { base.Common = value; }
        }            

        public $Prefix$$AddinPrefix$$EntityName$Impl(IslAppContext appContext)
            : base(appContext) {
            
            entityText = $Prefix$$AddinPrefix$ObjectNames.sObj$EntityName$;
            entityRegName = GetEntityRegName();            
        }

        protected override void InitInterfaces() {
            if (AppContext.IsServerContext) {
                Server = new $Prefix$$AddinPrefix$$EntityName$ImplServer(AppContext, this);
            }
            else {
                Client = new $Prefix$$AddinPrefix$$EntityName$ImplClient(AppContext, this);
            }
            Common = new $Prefix$$AddinPrefix$$EntityName$ImplCommon(AppContext, this);
        }        
       
        public static string GetEntityRegName() {
            return $Prefix$$AddinPrefix$Sys.GetRegName($Prefix$$AddinPrefix$ObjRegName.$EntityName$); 
        }
    }
}
