﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SLnet.Base;
using SLnet.Base.Attributes;
using SLnet.Base.DataObjects;
using SLnet.Base.Interfaces;
using $DomainName$.Core.Base;
using $DomainName$.Core.Base.Trace;
using $Prefix$$AddinName$.Data.DataObjects;
using $Prefix$$AddinName$.Data.Structure;
using $safeprojectname$.Implementors;

namespace $safeprojectname$ {

    partial class $Prefix$$AddinPrefix$$EntityName$ {
        [slWorkflowNonVisible()]
        public class Client_Get : slBaseObjectOperation {
            [slOperationMethod]
            public $Prefix$$AddinPrefix$$EntityName$Collection Execute(slDataObjectProviderFetchPath fetchPath) {                
                $Prefix$$AddinPrefix$$EntityName$Impl impl = new $Prefix$$AddinPrefix$$EntityName$Impl(AppContext);                
                return ($Prefix$$AddinPrefix$$EntityName$Collection)impl.Client.Get(impl.entityRegName, "Get", fetchPath);
            }
        }

        [slWorkflowNonVisible()]
        public class Client_GetByID : slBaseObjectOperation {
            [slOperationMethod]
            public $Prefix$$AddinPrefix$$EntityName$Collection Execute(string ID) {                
                $Prefix$$AddinPrefix$$EntityName$Impl impl = new $Prefix$$AddinPrefix$$EntityName$Impl(AppContext);
                return ($Prefix$$AddinPrefix$$EntityName$Collection)impl.Client.GetByID(impl.entityRegName, "GetByID", ID);
            }
        }

        [slWorkflowNonVisible()]
        public class Client_GetWithoutWorkflow : slBaseObjectOperation {
            [slOperationMethod]
            public $Prefix$$AddinPrefix$$EntityName$Collection Execute(slDataObjectProviderFetchPath fetchPath) {
                $Prefix$$AddinPrefix$$EntityName$Impl impl = new $Prefix$$AddinPrefix$$EntityName$Impl(AppContext);
                return ($Prefix$$AddinPrefix$$EntityName$Collection)impl.Client.GetWithoutWorkflow(impl.entityRegName, "GetWithoutWorkflow", fetchPath);
            }
        }

        [slWorkflowNonVisible()]
        public class Client_Delete : slBaseObjectOperation {
            [slOperationMethod]
            public $DomainPrefix$MessageLogger Execute(slDataObjectProviderFetchPath fetchPath) {               
                $Prefix$$AddinPrefix$$EntityName$Impl impl = new $Prefix$$AddinPrefix$$EntityName$Impl(AppContext);                
                return impl.Client.Delete(impl.entityRegName, "Delete", fetchPath);
            }
        }

        [slWorkflowNonVisible()]
        public class Client_DeleteByIDs : slBaseObjectOperation {
            [slOperationMethod]
            public $DomainPrefix$MessageLogger Execute(List<string> IDs) {                
                $Prefix$$AddinPrefix$$EntityName$Impl impl = new $Prefix$$AddinPrefix$$EntityName$Impl(AppContext);                
                return impl.Client.DeleteByIDs(impl.entityRegName, "DeleteByIDs", IDs);
            }
        }

        [slWorkflowNonVisible()]
        public class Client_DeleteByIDsIndividually : slBaseObjectOperation {
            [slOperationMethod]
            public $DomainPrefix$MessageLogger Execute(List<string> IDs) {
                $Prefix$$AddinPrefix$$EntityName$Impl impl = new $Prefix$$AddinPrefix$$EntityName$Impl(AppContext);                
                return impl.Client.DeleteByIDs(impl.entityRegName, "DeleteByIDsIndividually", IDs);
            }
        }

        [slWorkflowNonVisible()]
        public class Client_Post : slBaseObjectOperation {
            [slOperationMethod]
            public $DomainPrefix$MessageLogger Execute($Prefix$$AddinPrefix$$EntityName$Collection collection) {                
                $Prefix$$AddinPrefix$$EntityName$Impl impl = new $Prefix$$AddinPrefix$$EntityName$Impl(AppContext);
                return impl.Client.Post(impl.entityRegName, "Post", collection);                                
            }
        }                

        [slWorkflowNonVisible()]
        public class Client_SaveWarnings : slBaseObjectOperation {
            [slOperationMethod]
            public $DomainPrefix$MessageLogger Execute($Prefix$$AddinPrefix$$EntityName$Collection collection) {
                $Prefix$$AddinPrefix$$EntityName$Impl impl = new $Prefix$$AddinPrefix$$EntityName$Impl(AppContext);                           
                return impl.Client.SaveWarnings(impl.entityRegName, "SaveWarnings", collection);
            }
        }

        [slWorkflowNonVisible()]
        public class Client_DeleteWarnings : slBaseObjectOperation {
            [slOperationMethod]
            public $DomainPrefix$MessageLogger Execute($Prefix$$AddinPrefix$$EntityName$Collection collection) {
                $Prefix$$AddinPrefix$$EntityName$Impl impl = new $Prefix$$AddinPrefix$$EntityName$Impl(AppContext);
                return impl.Client.SaveWarnings(impl.entityRegName, "DeleteWarnings", collection);
            }
        }

        [slWorkflowNonVisible()]
        public class Client_SaveErrors : slBaseObjectOperation {
            [slOperationMethod]
            public $DomainPrefix$MessageLogger Execute($Prefix$$AddinPrefix$$EntityName$Collection collection) {
                $Prefix$$AddinPrefix$$EntityName$Impl impl = new $Prefix$$AddinPrefix$$EntityName$Impl(AppContext);
                return impl.Client.SaveErrors(collection);
            }
        }

    }
}
