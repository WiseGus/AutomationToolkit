﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SLnet.Sand.Base;
using SLnet.Base.Interfaces;
using SLnet.Base.Attributes;
using SLnet.Base;
using System.Data;
using SLnet.Base.DbUtils.Interfaces;
using SLnet.Base.Utils;
using SLnet.Base.DbUtils;
using Reeb.SqlOM;
using Reeb.SqlOM.Render;
using $Prefix$$AddinName$.Core.Base;

namespace $ProjectName$ {

    [slRegisterObject($Prefix$$AddinPrefix$ObjRegName.DomainName, $Prefix$$AddinPrefix$ObjRegName.$EntityName$)]
	public class $Prefix$$AddinPrefix$$EntityName$: slsEntity {

        public $Prefix$$AddinPrefix$$EntityName$(IslAppContext appContext)
            : base(appContext) {

        }


	}
}
