﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SLnet.Base.Interfaces;
using SLnet.Sand.Base.Attributes;
using $DomainName$.Core.Base;
using $DomainName$.Core.Messages;
using $DomainName$.Core.WpfForms;
using $Prefix$$AddinName$.Core.Base;

namespace $ProjectName$ {
    
    [slsRegisterForm($Prefix$$AddinPrefix$ObjRegName.DomainName, $Prefix$$AddinPrefix$ObjRegName.$EntityName$List)]
    public partial class $Prefix$$AddinPrefix$$EntityName$List : $DomainPrefix$BrowseF {
        
        new protected $Prefix$$AddinPrefix$$EntityName$Helper ListHelper {
            get { return base.ListHelper as $Prefix$$AddinPrefix$$EntityName$Helper; }
            set { base.ListHelper = value; }
        }

        public $Prefix$$AddinPrefix$$EntityName$List() {
            InitializeComponent();            
        }

        public override void Init(IslAppContext appContext) {
            base.Init(appContext);
            ListHelper = new $Prefix$$AddinPrefix$$EntityName$Helper(appContext);
            //TODO: define signature fields
            SignatureFields = new List<string>() { "XXX" };
        }

        protected override bool BrowserStructSupport() {
            return true;
        }

        public override string GetBrowserDefinition() {
            //TODO: Check the browser name    
           return "$Prefix$$AddinPrefix$$EntityName$";
        }

        public override string GetFormName() {
             //TODO: Check the form name 
            return "$AddinDomainName$:UI.$AliasName$:$EntityName$";
        }

        public override string GetListDescription() {
            //TODO: Check the resource string              
            return $Prefix$$AddinPrefix$Resources.sListName;
        }


        public override string GetObjectDescription() {            
            return $Prefix$$AddinPrefix$ObjectNames.sObj$EntityName$;
        }       

    }
}
