﻿using System;
using System.Linq;
using System.Text;
using SLnet.Base.Interfaces;
using $DomainName$.Core.Base;
using $DomainName$.Core.WpfForms;
using $Prefix$$AddinName$.Core.Base;

namespace $ProjectName$ {

    public class $Prefix$$AddinPrefix$$EntityName$Helper : $DomainPrefix$WpfObjectHelper {
        
        public $Prefix$$AddinPrefix$$EntityName$Helper(IslAppContext appContext)
            : base(appContext) {
        }

        public override string GetEntityRegName() {
            return $Prefix$$AddinPrefix$Sys.GetRegName($Prefix$$AddinPrefix$ObjRegName.$EntityName$);
        }

        public override bool GetDeleteIndividually() {
            return true;
        }
    }

}
