using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using SLnet.Base.Attributes;
using SLnet.Sand.Base.Attributes;
using $DomainName$.Core.Base;
using $DomainName$.Core.Base.Trace;
using $DomainName$.Core.Messages;
using $DomainName$.Core.WinForms;
using $Prefix$$AddinName$.Data.DataObjects;
using $Prefix$$AddinName$.PRS.$EntityName$;
using $Prefix$$AddinName$.Core.Base;

namespace $ProjectName$ {

    [slsRegisterForm($Prefix$$AddinPrefix$ObjRegName.DomainName, $Prefix$$AddinPrefix$ObjRegName.$EntityName$)]
    public partial class $Prefix$$AddinPrefix$$EntityName$F : $DomainPrefix$ArrayDefinitionF, I$Prefix$$AddinPrefix$$EntityName$View {

        public $Prefix$$AddinPrefix$$EntityName$F() {
            InitializeComponent();
            BindingSources.Add(bs$EntityName$);            
            this.Text =  $Prefix$$AddinPrefix$ObjectNames.sObj$EntityName$;
            this.Description = $Prefix$$AddinPrefix$ObjectNames.sObj$EntityName$;
        }
        
        private $Prefix$$AddinPrefix$$EntityName$P _Presenter;

        [slActivatorDependency(slDependencyTarget.CreateAndAssign)]
        new public $Prefix$$AddinPrefix$$EntityName$P Presenter {
            get { return _Presenter; }
            set { 
                _Presenter = value;
                base.Presenter = value;
            }
        }

        //TODO: override FocusFirstAvailableField()

        #region I$Prefix$$AddinPrefix$$EntityName$View Members

        public new $Prefix$$AddinPrefix$$EntityName$DataObject CurrentItem {
            get {
                return base.CurrentItem as $Prefix$$AddinPrefix$$EntityName$DataObject;
            }
            set {
                base.CurrentItem = value;
            }
        }

        public new $Prefix$$AddinPrefix$$EntityName$Collection Items {
            get {
                return base.Items as $Prefix$$AddinPrefix$$EntityName$Collection;
            }
            set {
                base.Items = value;
            }
        }

        #endregion

    }
}
