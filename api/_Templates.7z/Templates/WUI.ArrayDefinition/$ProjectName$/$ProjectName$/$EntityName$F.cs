using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using SLnet.Base.Attributes;
using SLnet.Sand.Base.Attributes;
using $DomainName$.Core.Base;
using $DomainName$.Core.Base.Trace;
using $DomainName$.Core.Messages;
using $DomainName$.Core.WinForms;
using $DomainName$.Data.DataObjects;
using $DomainName$.PRS.$ModuleName$.$EntityName$;

namespace $ProjectName$ {

    [slsRegisterForm($DomainPrefix$ObjRegName.$DomainNameFull$, "$EntityName$")]
    public partial class $DomainPrefix$$EntityName$F : $DomainPrefix$ArrayDefinitionF, I$DomainPrefix$$EntityName$View {

        public $DomainPrefix$$EntityName$F() {
            InitializeComponent();
            BindingSources.Add(bs$EntityName$);            
            this.Text = $DomainPrefix$ObjectNames.sObj$EntityName$;
            this.Description = $DomainPrefix$ObjectNames.sObj$EntityName$; 
        }
        
        private $DomainPrefix$$EntityName$P _Presenter;

        [slActivatorDependency(slDependencyTarget.CreateAndAssign)]
        new public $DomainPrefix$$EntityName$P Presenter {
            get { return _Presenter; }
            set { 
                _Presenter = value;
                base.Presenter = value;
            }
        }

        //TODO: override FocusFirstAvailableField()

        #region I$DomainPrefix$$EntityName$View Members

        public new $DomainPrefix$$EntityName$DataObject CurrentItem {
            get {
                return base.CurrentItem as $DomainPrefix$$EntityName$DataObject;
            }
            set {
                base.CurrentItem = value;
            }
        }

        public new $DomainPrefix$$EntityName$Collection Items {
            get {
                return base.Items as $DomainPrefix$$EntityName$Collection;
            }
            set {
                base.Items = value;
            }
        }

        #endregion

    }
}
