﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using $DomainName$.Data.DataObjects;
using $DomainName$.Core.Presenters.Views;

namespace $ProjectName$ {

    public interface I$DomainPrefix$$EntityName$View : I$DomainPrefix$ArrayView<$DomainPrefix$$EntityName$Collection, $DomainPrefix$$EntityName$DataObject> {
    }

}
