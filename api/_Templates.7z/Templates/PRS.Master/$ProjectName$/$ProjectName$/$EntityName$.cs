﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SLnet.Base.Attributes;
using SLnet.Base.Interfaces;
using $DomainName$.Entities;
using $DomainName$.Core.Base.SandExtensions;
using $DomainName$.Core.Messages;
using $DomainName$.Core.Presenters;
using $DomainName$.ENT.$ModuleName$.$EntityName$.Implementors;
using $ProjectName$.Views;

namespace $ProjectName$ {

    public class $DomainPrefix$$EntityName$P : $DomainPrefix$MasterPresenter<I$DomainPrefix$$EntityName$View, $DomainPrefix$$EntityName$EntityBase> {

        public $DomainPrefix$$EntityName$P(IslAppContext appContext, I$DomainPrefix$$EntityName$View view, $DomainPrefix$$EntityName$EntityBase entity)
            : base(appContext, view, entity, $DomainPrefix$$EntityName$Impl.GetEntityRegName(), $DomainPrefix$ObjectNames.sObj$EntityName$) {
        }

        [slDependencyConstructor]
        public $DomainPrefix$$EntityName$P(IslAppContext appContext, I$DomainPrefix$$EntityName$View view) 
            : this(appContext, view, null) {
        }
       
    }

}
